import Foundation

// Feladat 5: A kód nem fordul, mi a baj?

// ✋🏽 Ehhez ne nyúlj! 🛑
let a: Double = 6.0
let b: Int = 3
// Idáig

print(a/Double(b))
