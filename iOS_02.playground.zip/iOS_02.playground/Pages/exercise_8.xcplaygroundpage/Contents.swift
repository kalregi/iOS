import Foundation

// Feladat 8: Add össze a és b értékeket mint számokat

// ✋🏽 Ehhez ne nyúlj! 🛑
let a: String = "123.0"
let b: String = "11.1"
// Idáig

//let v = Double("Hello World")

let c: Double = (Double(a) ?? 0.0) + (Double(b) ?? 0.0) // valahogy

if c == 134.1 {
    print("🐽")
}
