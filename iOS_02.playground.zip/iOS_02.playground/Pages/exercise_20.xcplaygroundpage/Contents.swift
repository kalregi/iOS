import Foundation

// Feladat 20: nagy feladat 3
// Írj egy általános Life-like cellular automaton-t
// A Game of Life általánosítását kell megcsinálni

// Van egy négyzethálós cellákból áló mezőnk ahol minden cella vagy él vagy halott
// Iterációnként értékeljük ki a szabályokat és döntjük el, hogy melyik mező él vagy hal meg
// Minden cellának vannak szomszédai, összesen max 8 szomszédja lehet egy cellának (széleken kérdéses)

// Két féle szabály van:
//      * Survive (S): felsorolás szerűen hány darab élő szomszéd esetén él túl egy cella a következő iterációba
//      * Born (B): felsorolás szerűen hány darab élő szomszéd esetén születik (támad fel) egy cella

// A megejelnítést command lineon csináljátok jó öreg ascii art segítségével
// Ehhez is érdemes egy XCode command line projektet csinálni

// Pl. A jól ismert Game of Life kifejezhető ezekkel a szabályokkal: B3/S23
//          * pontosan 3 szomszéd esetén feltámad egy cella
//          * pontosan 2 vagy 3 szomszéd esetén túlél egy már élő cella a következő iterációba


class GameOfLife {
    var table = Array<Array<Bool>>()
    let LENGTH: Int
    let ITERATION_COUNT: Int
    let stayAlive: Array<Int>
    let rebirth: Array<Int>
    
    init(size: Int, iteration: Int, stayAlive: Array<Int>, rebirth: Array<Int>) {
        self.LENGTH = size
        self.ITERATION_COUNT=iteration
        self.stayAlive=stayAlive
        self.rebirth=rebirth
        for row in 0..<LENGTH {
            table.append(Array<Bool>())
            for cell in 0..<LENGTH {
                table[row].append(arc4random() % 2 == 0)
            }
        }
    }
    
    func countAliveNeighbours(row: Int, cell: Int) -> Int {
        var count = 0
        if row > 0 {
            if cell > 0 {
                if table[row-1][cell-1]{
                    count+=1
                }
            }
            if table[row-1][cell]{
                count+=1
            }
            if cell < LENGTH-1 {
                if table[row-1][cell+1]{
                    count+=1
                }
            }
        }
        
        if cell > 0 {
            if table[row][cell-1]{
                count+=1
            }
        }
        if cell < LENGTH-2 {
            if table[row][cell+1]{
                count+=1
            }
        }
        
        if row < LENGTH-1 {
            if cell > 0 {
                if table[row+1][cell-1]{
                    count+=1
                }
            }
            if table[row+1][cell]{
                count+=1
            }
            if cell < LENGTH-1 {
                if table[row+1][cell+1]{
                    count+=1
                }
            }
        }
        return count
    }
    
    func iterate() {
        var newTable = Array<Array<Bool>>()
        for row in 0..<LENGTH {
            newTable.append(Array<Bool>())
            for _ in 0..<LENGTH {
                newTable[row].append(false)
            }
        }
        for row in 0..<LENGTH {
            for cell in 0..<LENGTH {
                let aliveNeighbours = countAliveNeighbours(row: row, cell: cell)
                if table[row][cell] {
                    newTable[row][cell] = stayAlive.contains(aliveNeighbours)
                } else {
                    newTable[row][cell] = rebirth.contains(aliveNeighbours)
                }
            }
        }
        table = newTable
    }
    
    func printTable(){
        for row in 0..<LENGTH {
            var rowPrint = ""
            for cell in 0..<LENGTH {
                if table[row][cell] {
                    rowPrint += "🐷"
                } else {
                    rowPrint += "☠️"
                }
            }
            print(rowPrint)
        }
    }
    
    func simulate(){
        print("Kezdő állapot:")
        printTable()
        print("")
        for i in 1...ITERATION_COUNT {
            iterate()
            print(String(i) + ". iteráció")
            printTable()
            print("")
        }
    }
}

var game = GameOfLife(size: 5, iteration: 3, stayAlive: [2,3], rebirth: [2])
game.simulate()

