import Foundation

// Feladat 18: nagy feladat 1
// Írj egy CaesarsCypher nevű osztályt ami komformál az Encryption protocolhoz
// A CaesarsCypher a jó öreg cézár titkosítást valósítsa meg
// A cézár titkosítás lényegében annyi, hogy a bemeneti karaktersort eltolja egy konstans értékkel
// Pl az "abc" eltolva 1 értékkel "bcd" 2 értékkel eltolva: "cde"
// Pl "Kismalac" eltolva 1 értékkel "Ljtnbmbd"

// Érdemes a feladathoz létrehozni egy XCode command line projektet. XCode > New Project > macOS > Command Line Tool

protocol Encryption {
    func encrypt(plaintext: String) -> String?
    func decrypt(cyphertext: String) -> String?
}

class CaesarsCypher: Encryption {
    let abc = ["a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z"]
    
    func encrypt(plaintext: String) -> String? {
        var result = "";
        for char in plaintext {
            for i in 0..<abc.count {
                if(String(char).uppercased() != String(char)){
                    if abc[i] == String(char) {
                        if i == abc.count-1 {
                            result += abc[0]
                        } else {
                            result += abc[i+1]
                        }
                    }
                } else {
                    if abc[i].uppercased() == String(char) {
                        if i == abc.count-1 {
                            result += abc[0].uppercased()
                        } else {
                            result += abc[i+1].uppercased()
                        }
                    }
                }
            }
        }
        return result
    }
    
    func decrypt(cyphertext: String) -> String? {
        var result = "";
        for char in cyphertext {
            for i in 0..<abc.count {
                if(String(char).uppercased() != String(char)){
                    if abc[i] == String(char) {
                        if i == abc.count-1 {
                            result += abc[0]
                        } else {
                            result += abc[i-1]
                        }
                    }
                } else {
                    if abc[i].uppercased() == String(char) {
                        if i == 0 {
                            result += abc[abc.count-1].uppercased()
                        } else {
                            result += abc[i-1].uppercased()
                        }
                    }
                }
            }
        }
        return result
    }
}

var cypher = CaesarsCypher()

if cypher.encrypt(plaintext: "Kismalac") == "Ljtnbmbd" {
    print("👍")
} else {
    print("🙁")
}

if cypher.decrypt(cyphertext: "Ljtnbmbd") == "Kismalac" {
    print("👍")
} else {
    print("🙁")
}
