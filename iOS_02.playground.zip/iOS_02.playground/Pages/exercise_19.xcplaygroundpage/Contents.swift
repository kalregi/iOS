import Foundation

// Feladat 19: nagy feladat 2
// Írj egy OneTimePad nevű osztályt ami a one-time-pad titkosítást valósítja meg
// A OneTimePad komformáljon az Encryption protocolhoz
// A one-time pad titkosítás feltörhetetlen (tényleg)
// A one-time pad titkosítás lényegében annyi, hogy egy szövegnek a karaktereit eltolja egy másik "kulcs" karaktersorozat értékeivel
// Ehhez is érdemes egy XCode command line projektet csinálni

// Pl "abc" eltolva a "afd" kulcsal: "bhg"
// (mert a: 1, b: 2, c: 3    a: 1, f: 6, d: 4  a+a = 1+1 = 2 = b, b+f = 2+6 = 8 = h, c+d = 3+4 = 7 = g -> "bhg")

protocol Encryption {
    func encrypt(plaintext: String) -> String?
    func decrypt(cyphertext: String) -> String?
}

class OneTimePad : Encryption {
    let abc = ["a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z"]
    
    let key : String
    var keyInts : Array<Int>
    
    func toInt(_ char : String) -> Int? {
        for i in 0..<abc.count {
            if abc[i] == char {
                return i
            }
        }
        return nil
    }
    
    func toChar(_ index : Int) -> String? {
        guard index < abc.count else {
            return nil
        }
        return abc[index]
    }
    
    init(key: String) {
        self.key = key
        self.keyInts = Array<Int>()
        for k in self.key {
            guard let i = toInt(String(k)) else {
                fatalError()
            }
            self.keyInts.append(i+1)
        }
    }
    
    func encryptChar(char : String, key: Int) -> String? {
        guard let baseInt = toInt(char) else {
            return nil
        }
        return toChar(baseInt+key % abc.count)
    }
    
    func decryptChar(char : String, key: Int) -> String? {
        guard let baseInt = toInt(char) else {
            return nil
        }
        return toChar(baseInt-key % abc.count)
    }
    
    func encrypt(plaintext: String) -> String? {
        guard plaintext.count <= key.count else {
            return nil
        }
        var result = ""
        for i in 0..<plaintext.count {
            guard let encyptedChar = encryptChar(char: String(Array(plaintext)[i]), key: keyInts[i])
                else {
                    return nil
            }
            result += encyptedChar
        }
        return result
    }
    
    func decrypt(cyphertext: String) -> String? {
        guard cyphertext.count <= key.count else {
            return nil
        }
        var result = ""
        for i in 0..<cyphertext.count {
            guard let decriptedChar = decryptChar(char: String(Array(cyphertext)[i]), key: keyInts[i])
                else {
                    return nil
            }
            result += decriptedChar
        }
        return result
    }
    
    
}

var cypher = OneTimePad(key : "afd")
if (cypher.encrypt(plaintext: "abc") == "bhg") {
    print("👍")
} else {
    print("🙁")
}
if (cypher.decrypt(cyphertext: "bhg") == "abc") {
    print("👍")
} else {
    print("🙁")
}


