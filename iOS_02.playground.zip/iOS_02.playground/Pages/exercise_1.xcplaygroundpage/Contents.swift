//: Playground - noun: a place where people can play

import UIKit

// Feladat 1: Miért nem fordul a kód?
let a: Int = 1
var b: Int = 2
var c = a + b
b = 3
c = a + 2 * b
print(c)
