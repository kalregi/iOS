import Foundation

// Feladat 17: Adjuk össze 1-től 100-ig a természetes számok négyzetei közül a páratlanokat

let arr = Array(1...100)

var sum = 0

for e in arr{
    if e*e % 2 == 1{
        sum+=e*e
    }
}

if sum == 166650 {
    print("🐽")
}
